#include "loginwindow.h"
#include "ui_loginwindow.h"
#include "registerdialog.h"
#include "mainwindow.h"
#include "cajerowindow.h"
#include "adminwindow.h"
#include "devwindow.h"
#include "sistemabuffet.h"
#include <QMessageBox>
#include <QAction>

LoginWindow::LoginWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginWindow),
    m_intentosFallidos(0)
{
    ui->setupUi(this);
    setWindowTitle("El Buffet de Alejandro - Iniciar Sesión");

    // Inicializar datos del sistema
    SistemaBuffet::inicializarDatos();

    // Límites de longitud básicos (sin validadores bloqueantes)
    ui->txtPass->setMaxLength(12);
    ui->txtPinCajero->setMaxLength(4);

    // Conectar tecla Enter (returnPressed) de los campos al botón Iniciar Sesión
    connect(ui->txtUser, &QLineEdit::returnPressed, this, &LoginWindow::on_btnLogin_clicked);
    connect(ui->txtPass, &QLineEdit::returnPressed, this, &LoginWindow::on_btnLogin_clicked);
    connect(ui->txtPinCajero, &QLineEdit::returnPressed, this, &LoginWindow::on_btnLogin_clicked);
    connect(ui->txtTokenDev, &QLineEdit::returnPressed, this, &LoginWindow::on_btnLogin_clicked);

    // Acción para ver / ocultar contraseña
    QAction *eyeAction = ui->txtPass->addAction(QString("👁️"), QLineEdit::TrailingPosition);
    connect(eyeAction, &QAction::triggered, this, [this, eyeAction]() {
        if (ui->txtPass->echoMode() == QLineEdit::Password) {
            ui->txtPass->setEchoMode(QLineEdit::Normal);
            eyeAction->setText("🙈");
        } else {
            ui->txtPass->setEchoMode(QLineEdit::Password);
            eyeAction->setText("👁️");
        }
    });

    actualizarCamposSegunRol(0);
}

LoginWindow::~LoginWindow()
{
    delete ui;
}

void LoginWindow::on_comboRole_currentIndexChanged(int index)
{
    actualizarCamposSegunRol(index);
}

void LoginWindow::actualizarCamposSegunRol(int index)
{
    switch (index) {
    case 0: // Estudiante
        ui->lblUser->setText("DNI del Estudiante o Correo Escolar:");
        ui->txtUser->setPlaceholderText("Ej. 44123456, alumno@bue.edu.ar o alumno");
        ui->lblPinCajero->hide();
        ui->txtPinCajero->hide();
        ui->lblTokenDev->hide();
        ui->txtTokenDev->hide();
        ui->lblNoAccount->show();
        ui->btnGoRegister->show();
        ui->lblNoticeRol->setText("Estudiantes: Iniciar con DNI o correo @bue.edu.ar (clave mín. 4 caracteres).");
        break;

    case 1: // Personal de Buffet / Cajero
        ui->lblUser->setText("Legajo de Empleado (ID) o Usuario:");
        ui->txtUser->setPlaceholderText("Ej. cajero1, EMP-101 o cajero");
        ui->lblPinCajero->show();
        ui->txtPinCajero->show();
        ui->lblTokenDev->hide();
        ui->txtTokenDev->hide();
        ui->lblNoAccount->hide();
        ui->btnGoRegister->hide();
        ui->lblNoticeRol->setText("🔒 Personal de Buffet: Usuario 'cajero1' y PIN '1234'.");
        break;

    case 2: // Administrador
        ui->lblUser->setText("Usuario Administrador:");
        ui->txtUser->setPlaceholderText("Ej. admin");
        ui->lblPinCajero->hide();
        ui->txtPinCajero->hide();
        ui->lblTokenDev->hide();
        ui->txtTokenDev->hide();
        ui->lblNoAccount->hide();
        ui->btnGoRegister->hide();
        ui->lblNoticeRol->setText("Administración: Usuario 'admin' y clave 'admin123'.");
        break;

    case 3: // Desarrollador / Soporte Técnico
        ui->lblUser->setText("Usuario Desarrollador:");
        ui->txtUser->setPlaceholderText("Ej. dev");
        ui->lblPinCajero->hide();
        ui->txtPinCajero->hide();
        ui->lblTokenDev->show();
        ui->txtTokenDev->show();
        ui->lblNoAccount->hide();
        ui->btnGoRegister->hide();
        ui->lblNoticeRol->setText("Desarrollador: Token 'DEV-BEREA-2026'.");
        break;
    }
}

void LoginWindow::on_btnLogin_clicked()
{
    QString usuario = ui->txtUser->text().trimmed();
    QString password = ui->txtPass->text();
    int indexRol = ui->comboRole->currentIndex();

    if (m_intentosFallidos >= 3) {
        QMessageBox::critical(this, "Bloqueado", "Superó el límite de 3 intentos fallidos.");
        return;
    }

    if (usuario.isEmpty() || password.isEmpty()) {
        m_intentosFallidos++;
        QMessageBox::warning(this, "Datos Incompletos", "Por favor completa usuario y contraseña.");
        return;
    }

    if (password.length() < 4) {
        m_intentosFallidos++;
        QMessageBox::warning(this, "Contraseña Corta", "La contraseña debe tener al menos 4 caracteres.");
        return;
    }

    if (indexRol == 0) { // Estudiante
        if ((usuario == SistemaBuffet::usuarioDni || usuario == "44123456" || usuario.contains("@") || usuario.toLower() == "alumno") &&
            (password.length() >= 4)) {
            m_intentosFallidos = 0;
            MainWindow *mainWin = new MainWindow();
            mainWin->show();
            this->close();
        } else {
            m_intentosFallidos++;
            int res = QMessageBox::warning(this, "Acceso Denegado",
                "Estudiante no encontrado o contraseña errónea.\n¿Deseas registrarte?",
                QMessageBox::Yes | QMessageBox::No);
            if (res == QMessageBox::Yes) {
                RegisterDialog regDlg(this);
                regDlg.exec();
            }
        }
    }
    else if (indexRol == 1) { // Personal de Buffet
        QString pin = ui->txtPinCajero->text().trimmed();
        if (pin.length() != 4) {
            QMessageBox::warning(this, "PIN Inválido", "El PIN debe tener exactamente 4 dígitos.");
            return;
        }

        if ((usuario == "cajero1" || usuario == "EMP-101" || usuario == "cajero") && pin == "1234") {
            m_intentosFallidos = 0;
            CajeroWindow *cajeroWin = new CajeroWindow();
            cajeroWin->show();
            this->close();
        } else {
            m_intentosFallidos++;
            QMessageBox::critical(this, "Error", "Usuario o PIN de personal incorrectos (Prueba: cajero1 / PIN: 1234).");
        }
    }
    else if (indexRol == 2) { // Administrador
        if (usuario == "admin" && (password == "admin" || password == "admin123" || password == "123456")) {
            m_intentosFallidos = 0;
            AdminWindow *adminWin = new AdminWindow();
            adminWin->show();
            this->close();
        } else {
            m_intentosFallidos++;
            QMessageBox::critical(this, "Error", "Credenciales de administrador incorrectas (Prueba: admin / admin123).");
        }
    }
    else if (indexRol == 3) { // Desarrollador
        QString token = ui->txtTokenDev->text().trimmed();
        if (token != "DEV-BEREA-2026") {
            m_intentosFallidos++;
            QMessageBox::warning(this, "Token Inválido", "El token de desarrollador es DEV-BEREA-2026.");
            return;
        }

        m_intentosFallidos = 0;
        DevWindow *devWin = new DevWindow();
        devWin->show();
        this->close();
    }
}

void LoginWindow::on_btnGoRegister_clicked()
{
    RegisterDialog regDlg(this);
    regDlg.exec();
}
