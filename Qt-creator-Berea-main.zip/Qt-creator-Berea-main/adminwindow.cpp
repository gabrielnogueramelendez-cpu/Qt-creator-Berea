#include "adminwindow.h"
#include "ui_adminwindow.h"
#include "loginwindow.h"
#include "sistemabuffet.h"
#include <QMessageBox>
#include <QTableWidgetItem>
#include <QDateTime>
#include <QIntValidator>

AdminWindow::AdminWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AdminWindow)
{
    ui->setupUi(this);
    setWindowTitle("Panel de Administración - Gestor del Buffet");

    // Validador numérico de stock visto en la guía Gestor de Inventario (slide 17)
    ui->txtStockProd->setValidator(new QIntValidator(0, 9999, this));
    ui->txtNombreProd->setMaxLength(50);
    ui->txtPrecioProd->setMaxLength(10);

    // Selección por fila completa
    ui->tableProductosAdmin->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableProductosAdmin->setSelectionMode(QAbstractItemView::SingleSelection);

    cargarInventarioSimulado();
    cargarLogsSimulados();
}

AdminWindow::~AdminWindow()
{
    delete ui;
}

void AdminWindow::cargarInventarioSimulado()
{
    ui->tableProductosAdmin->setRowCount(0);
    ui->tableProductosAdmin->setColumnCount(5);
    QStringList headers;
    headers << "ID" << "Producto" << "Categoría" << "Precio" << "Stock";
    ui->tableProductosAdmin->setHorizontalHeaderLabels(headers);
    ui->tableProductosAdmin->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);

    // Productos iniciales del buffet
    QStringList nombres = {"Sándwich de Milanesa", "Empanada Criolla", "Alfajor de Chocolate", "Agua Mineral 500ml", "Tostado Jamón y Queso"};
    QStringList categorias = {"Comidas Rápidas", "Comidas Rápidas", "Snacks y Dulces", "Bebidas", "Comidas Rápidas"};
    QStringList precios = {"2800", "950", "800", "650", "2200"};
    QStringList stocks = {"15", "30", "40", "50", "20"};

    for (int i = 0; i < nombres.size(); ++i) {
        ui->tableProductosAdmin->insertRow(i);
        ui->tableProductosAdmin->setItem(i, 0, new QTableWidgetItem(QString::number(i + 1)));
        ui->tableProductosAdmin->setItem(i, 1, new QTableWidgetItem(nombres[i]));
        ui->tableProductosAdmin->setItem(i, 2, new QTableWidgetItem(categorias[i]));
        ui->tableProductosAdmin->setItem(i, 3, new QTableWidgetItem(precios[i]));
        ui->tableProductosAdmin->setItem(i, 4, new QTableWidgetItem(stocks[i]));
    }
}

void AdminWindow::cargarLogsSimulados()
{
    ui->tableLogsAdmin->setRowCount(0);
    ui->tableLogsAdmin->setColumnCount(4);
    QStringList headers;
    headers << "Fecha / Hora" << "Usuario / Rol" << "Acción" << "Detalle Evento";
    ui->tableLogsAdmin->setHorizontalHeaderLabels(headers);
    ui->tableLogsAdmin->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);

    int row = ui->tableLogsAdmin->rowCount();
    ui->tableLogsAdmin->insertRow(row);
    ui->tableLogsAdmin->setItem(row, 0, new QTableWidgetItem(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss")));
    ui->tableLogsAdmin->setItem(row, 1, new QTableWidgetItem("Admin (Encargado)"));
    ui->tableLogsAdmin->setItem(row, 2, new QTableWidgetItem("INICIO_SESION"));
    ui->tableLogsAdmin->setItem(row, 3, new QTableWidgetItem("Apertura de sesión del panel administrativo"));
}

void AdminWindow::on_btnAgregarProd_clicked()
{
    QString nombre = ui->txtNombreProd->text().trimmed();
    QString cat = ui->comboCategoria->currentText();
    QString precioStr = ui->txtPrecioProd->text().trimmed();
    QString stockStr = ui->txtStockProd->text().trimmed();

    if (nombre.isEmpty() || precioStr.isEmpty() || stockStr.isEmpty()) {
        QMessageBox::warning(this, "Campos Incompletos", "Por favor completa todos los campos para agregar un nuevo producto.");
        return;
    }

    bool okPrecio = false;
    double precio = precioStr.toDouble(&okPrecio);
    if (!okPrecio || precio <= 0.0) {
        QMessageBox::warning(this, "Precio Inválido", "El precio debe ser un número mayor a 0.");
        return;
    }

    bool okStock = false;
    int stock = stockStr.toInt(&okStock);
    if (!okStock || stock < 0) {
        QMessageBox::warning(this, "Stock Inválido", "El stock debe ser un número entero mayor o igual a 0.");
        return;
    }

    int nuevaFila = ui->tableProductosAdmin->rowCount();
    int nuevoId = nuevaFila + 1;
    ui->tableProductosAdmin->insertRow(nuevaFila);
    ui->tableProductosAdmin->setItem(nuevaFila, 0, new QTableWidgetItem(QString::number(nuevoId)));
    ui->tableProductosAdmin->setItem(nuevaFila, 1, new QTableWidgetItem(nombre));
    ui->tableProductosAdmin->setItem(nuevaFila, 2, new QTableWidgetItem(cat));
    ui->tableProductosAdmin->setItem(nuevaFila, 3, new QTableWidgetItem(QString::number(precio, 'f', 0)));
    ui->tableProductosAdmin->setItem(nuevaFila, 4, new QTableWidgetItem(QString::number(stock)));

    int logFila = ui->tableLogsAdmin->rowCount();
    ui->tableLogsAdmin->insertRow(logFila);
    ui->tableLogsAdmin->setItem(logFila, 0, new QTableWidgetItem(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss")));
    ui->tableLogsAdmin->setItem(logFila, 1, new QTableWidgetItem("Admin (Encargado)"));
    ui->tableLogsAdmin->setItem(logFila, 2, new QTableWidgetItem("ALTA_PRODUCTO"));
    ui->tableLogsAdmin->setItem(logFila, 3, new QTableWidgetItem("Se agregó producto: " + nombre + " ($" + QString::number(precio, 'f', 0) + ")"));

    QMessageBox::information(this, "Producto Agregado",
        QString("El producto '%1' fue registrado exitosamente con precio $%2 y stock %3.")
            .arg(nombre).arg(QString::number(precio, 'f', 0)).arg(stock));

    ui->txtNombreProd->clear();
    ui->txtPrecioProd->clear();
    ui->txtStockProd->clear();
}

void AdminWindow::on_btnGuardarEdit_clicked()
{
    int fila = ui->tableProductosAdmin->currentRow();
    if (fila == -1) {
        QMessageBox::warning(this, "Error", "No seleccionó ninguna fila para modificar.");
        return;
    }

    int id = ui->tableProductosAdmin->item(fila, 0)->text().toInt();
    QString nombre = ui->tableProductosAdmin->item(fila, 1)->text();
    QString precioStr = ui->tableProductosAdmin->item(fila, 3)->text().replace("$", "").trimmed();
    QString stockStr = ui->tableProductosAdmin->item(fila, 4)->text().trimmed();

    bool okP = false;
    double precio = precioStr.toDouble(&okP);
    if (!okP || precio <= 0) {
        QMessageBox::warning(this, "Precio Inválido", "El precio en la celda debe ser un número mayor a 0.");
        return;
    }

    bool okS = false;
    int stock = stockStr.toInt(&okS);
    if (!okS || stock < 0) {
        QMessageBox::warning(this, "Stock Inválido", "El stock en la celda debe ser un entero mayor o igual a 0.");
        return;
    }

    ui->tableProductosAdmin->item(fila, 3)->setText(QString::number(precio, 'f', 0));
    ui->tableProductosAdmin->item(fila, 4)->setText(QString::number(stock));

    int logFila = ui->tableLogsAdmin->rowCount();
    ui->tableLogsAdmin->insertRow(logFila);
    ui->tableLogsAdmin->setItem(logFila, 0, new QTableWidgetItem(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss")));
    ui->tableLogsAdmin->setItem(logFila, 1, new QTableWidgetItem("Admin (Encargado)"));
    ui->tableLogsAdmin->setItem(logFila, 2, new QTableWidgetItem("MODIFICACION_PRODUCTO"));
    ui->tableLogsAdmin->setItem(logFila, 3, new QTableWidgetItem(QString("Modificado ID %1 (%2): Precio $%3, Stock %4").arg(id).arg(nombre).arg(QString::number(precio, 'f', 0)).arg(stock)));

    QMessageBox::information(this, "Cambios Guardados",
        QString("El producto ID %1 se actualizó con éxito (Precio: $%2, Stock: %3).")
            .arg(id).arg(QString::number(precio, 'f', 0)).arg(stock));
}

void AdminWindow::on_btnEliminarProd_clicked()
{
    int fila = ui->tableProductosAdmin->currentRow();
    if (fila == -1) {
        QMessageBox::warning(this, "Error", "No seleccionó ninguna fila para eliminar.");
        return;
    }

    QString id = ui->tableProductosAdmin->item(fila, 0)->text();
    QString nombre = ui->tableProductosAdmin->item(fila, 1)->text();

    QMessageBox::StandardButton resp = QMessageBox::question(this, "Confirmar Baja",
        QString("¿Estás seguro de que deseas eliminar '%1' del catálogo del buffet escolar?").arg(nombre),
        QMessageBox::Yes | QMessageBox::No);

    if (resp == QMessageBox::Yes) {
        ui->tableProductosAdmin->removeRow(fila);

        int logFila = ui->tableLogsAdmin->rowCount();
        ui->tableLogsAdmin->insertRow(logFila);
        ui->tableLogsAdmin->setItem(logFila, 0, new QTableWidgetItem(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss")));
        ui->tableLogsAdmin->setItem(logFila, 1, new QTableWidgetItem("Admin (Encargado)"));
        ui->tableLogsAdmin->setItem(logFila, 2, new QTableWidgetItem("BAJA_PRODUCTO"));
        ui->tableLogsAdmin->setItem(logFila, 3, new QTableWidgetItem("Se eliminó producto ID " + id + ": " + nombre));

        QMessageBox::information(this, "Producto Eliminado", "El producto fue removido correctamente.");
    }
}

void AdminWindow::on_btnLogout_clicked()
{
    LoginWindow *loginWin = new LoginWindow();
    loginWin->show();
    this->close();
}
