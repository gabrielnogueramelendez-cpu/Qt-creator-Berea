#include "pagodialog.h"
#include "ui_pagodialog.h"
#include "sistemabuffet.h"
#include <QMessageBox>
#include <QRandomGenerator>

PagoDialog::PagoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PagoDialog),
    m_totalPagar(0.0)
{
    ui->setupUi(this);
    setWindowTitle("💳 Verificación y Pago - El Buffet de Alejandro");

    m_totalPagar = SistemaBuffet::getTotalCarrito();
    ui->lblResumenTotal->setText(QString("Total a Pagar del Pedido: $%1")
        .arg(QString::number(m_totalPagar, 'f', 0)));

    // Límites de longitud básicos (sin validadores bloqueantes)
    ui->txtComprobanteMP->setMaxLength(4);

    cargarDatosAlumno();
    on_comboMetodoPago_currentIndexChanged(0);
}

PagoDialog::~PagoDialog()
{
    delete ui;
}

void PagoDialog::cargarDatosAlumno()
{
    ui->txtPagoDni->setText(SistemaBuffet::usuarioDni);
    ui->txtPagoNombre->setText(SistemaBuffet::usuarioNombre + " " + SistemaBuffet::usuarioApellido);
    ui->txtPagoCurso->setText(SistemaBuffet::usuarioCurso);
    ui->lblSaldoDisponible->setText(QString("Saldo disponible en tu cuenta escolar: $%1")
        .arg(QString::number(SistemaBuffet::usuarioSaldo, 'f', 0)));

    if (SistemaBuffet::usuarioSaldo >= m_totalPagar) {
        ui->lblEstadoSaldo->setText(QString("✅ Saldo suficiente. Te quedarán $%1.")
            .arg(QString::number(SistemaBuffet::usuarioSaldo - m_totalPagar, 'f', 0)));
    } else {
        ui->lblEstadoSaldo->setText("❌ Saldo insuficiente en cuenta escolar para cubrir el total.");
    }
}

void PagoDialog::on_comboMetodoPago_currentIndexChanged(int index)
{
    ui->stackedDetallePago->setCurrentIndex(index);
    if (index == 0) {
        on_txtMontoAbonado_textChanged(ui->txtMontoAbonado->text());
    }
}

void PagoDialog::on_txtMontoAbonado_textChanged(const QString &text)
{
    bool ok = false;
    double abonado = text.toDouble(&ok);
    if (ok && abonado >= m_totalPagar) {
        double vuelto = abonado - m_totalPagar;
        ui->lblVueltoCalculado->setText(QString("✅ Vuelto a recibir en caja: $%1")
            .arg(QString::number(vuelto, 'f', 0)));
    } else if (ok && abonado < m_totalPagar) {
        double falta = m_totalPagar - abonado;
        ui->lblVueltoCalculado->setText(QString("⚠️ Monto insuficiente (faltan $%1)").arg(QString::number(falta, 'f', 0)));
    } else {
        ui->lblVueltoCalculado->setText("Vuelto a recibir en caja: $0");
    }
}

void PagoDialog::on_btnCancelarPago_clicked()
{
    reject();
}

void PagoDialog::on_btnConfirmarPedido_clicked()
{
    QString dni = ui->txtPagoDni->text().trimmed();
    QString nombre = ui->txtPagoNombre->text().trimmed();
    QString curso = ui->txtPagoCurso->text().trimmed();

    if (dni.isEmpty() || nombre.isEmpty() || curso.isEmpty()) {
        QMessageBox::warning(this, "Datos Incompletos", "Por favor completa los datos del estudiante.");
        return;
    }

    if (!ui->chkConfirmarTerminos->isChecked()) {
        QMessageBox::warning(this, "Confirmación Requerida",
            "Debes marcar la casilla declarando el compromiso de retiro en el horario indicado.");
        return;
    }

    QString metodo = ui->comboMetodoPago->currentText();
    double montoAbonado = m_totalPagar;
    double vuelto = 0.0;

    if (metodo.contains("Efectivo", Qt::CaseInsensitive)) {
        bool ok = false;
        montoAbonado = ui->txtMontoAbonado->text().trimmed().toDouble(&ok);
        if (!ok || montoAbonado < m_totalPagar) {
            QMessageBox::critical(this, "Monto Insuficiente", "El monto ingresado es insuficiente para cubrir el total.");
            return;
        }
        vuelto = montoAbonado - m_totalPagar;
    } else if (metodo.contains("Saldo", Qt::CaseInsensitive)) {
        if (SistemaBuffet::usuarioSaldo < m_totalPagar) {
            QMessageBox::critical(this, "Saldo Insuficiente", "Saldo insuficiente en cuenta escolar.");
            return;
        }
        SistemaBuffet::usuarioSaldo -= m_totalPagar;
    } else if (metodo.contains("Mercado", Qt::CaseInsensitive)) {
        if (ui->txtComprobanteMP->text().trimmed().length() != 4) {
            QMessageBox::warning(this, "Comprobante Inválido", "Ingresa los 4 dígitos finales del comprobante.");
            return;
        }
    }

    QString recreo = ui->comboRecreo->currentText();

    // Generar código único de 5 caracteres
    const QString chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    QString codigo = "";
    for (int i = 0; i < 5; ++i) {
        int idx = QRandomGenerator::global()->bounded(chars.length());
        codigo.append(chars.at(idx));
    }

    // Registrar pedido en las listas paralelas de SistemaBuffet
    SistemaBuffet::pedidosCodigos.append(codigo);
    SistemaBuffet::pedidosAlumnos.append(nombre);
    SistemaBuffet::pedidosCursos.append(curso);
    SistemaBuffet::pedidosDnis.append(dni);
    SistemaBuffet::pedidosRecreos.append(recreo);
    SistemaBuffet::pedidosMetodos.append(metodo);
    SistemaBuffet::pedidosMontos.append(m_totalPagar);
    SistemaBuffet::pedidosAbonados.append(montoAbonado);
    SistemaBuffet::pedidosVueltos.append(vuelto);
    SistemaBuffet::pedidosEstados.append("PENDIENTE");

    QString itemsTexto = "";
    for (int i = 0; i < SistemaBuffet::carritoNombres.size(); ++i) {
        itemsTexto += QString("  • %1 x %2 ($%3)\n")
            .arg(SistemaBuffet::carritoCantidades[i])
            .arg(SistemaBuffet::carritoNombres[i])
            .arg(QString::number(SistemaBuffet::carritoPrecios[i] * SistemaBuffet::carritoCantidades[i], 'f', 0));
    }
    SistemaBuffet::pedidosDetalles.append(itemsTexto);

    // Vaciar el carrito tras confirmar la compra
    SistemaBuffet::vaciarCarrito();

    m_codigoGenerado = codigo;
    accept();
}
