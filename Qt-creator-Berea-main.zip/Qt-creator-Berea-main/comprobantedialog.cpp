#include "comprobantedialog.h"
#include "ui_comprobantedialog.h"
#include "sistemabuffet.h"

ComprobanteDialog::ComprobanteDialog(const QString &codigoRetiro, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ComprobanteDialog),
    m_codigo(codigoRetiro)
{
    ui->setupUi(this);
    setWindowTitle("Comprobante de Pedido - El Buffet de Alejandro");
    cargarDatosComprobante();
}

ComprobanteDialog::~ComprobanteDialog()
{
    delete ui;
}

void ComprobanteDialog::cargarDatosComprobante()
{
    ui->lblCode->setText(m_codigo);

    int idx = SistemaBuffet::pedidosCodigos.indexOf(m_codigo);
    if (idx != -1) {
        QString itemsTexto = SistemaBuffet::pedidosDetalles[idx];

        QString resumen = QString(
            "📋 RESUMEN OFICIAL DEL PEDIDO:\n"
            "- Estudiante: %1 (DNI %2 - %3)\n"
            "- Horario de Retiro: %4\n"
            "- Método de Pago: %5\n"
            "- Estado: %6\n"
            "- Ítems:\n%7"
            "- Total: $%8\n"
        ).arg(SistemaBuffet::pedidosAlumnos[idx])
         .arg(SistemaBuffet::pedidosDnis[idx])
         .arg(SistemaBuffet::pedidosCursos[idx])
         .arg(SistemaBuffet::pedidosRecreos[idx])
         .arg(SistemaBuffet::pedidosMetodos[idx])
         .arg(SistemaBuffet::pedidosEstados[idx])
         .arg(itemsTexto)
         .arg(QString::number(SistemaBuffet::pedidosMontos[idx], 'f', 0));

        if (SistemaBuffet::pedidosMetodos[idx].contains("Efectivo", Qt::CaseInsensitive)) {
            resumen += QString("- Abonó con: $%1 | Vuelto a recibir: $%2\n")
                .arg(QString::number(SistemaBuffet::pedidosAbonados[idx], 'f', 0))
                .arg(QString::number(SistemaBuffet::pedidosVueltos[idx], 'f', 0));
        }

        ui->lblDetails->setText(resumen);
        ui->lblRuleNotice->setText(QString("📱 Solo necesitas dictar el código '%1' o mostrar esta pantalla en el mostrador para retirar tu pedido.").arg(m_codigo));
    }
}

void ComprobanteDialog::on_btnClose_clicked()
{
    accept();
}
