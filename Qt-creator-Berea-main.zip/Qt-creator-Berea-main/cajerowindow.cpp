#include "cajerowindow.h"
#include "ui_cajerowindow.h"
#include "loginwindow.h"
#include "sistemabuffet.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QTableWidgetItem>

CajeroWindow::CajeroWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CajeroWindow)
{
    ui->setupUi(this);
    setWindowTitle("Panel del Personal de Buffet - Caja & Retiros");

    ui->btnEntregarPedido->setEnabled(false);
    ui->btnCancelarPedido->setEnabled(false);

    // Limitar longitud del código a 5 caracteres (sin validadores bloqueantes)
    ui->txtCodigoRetiro->setMaxLength(5);

    // Configurar selección completa de filas en la tabla de pedidos
    ui->tableColasPedidos->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableColasPedidos->setSelectionMode(QAbstractItemView::SingleSelection);

    cargarPedidosDelSistema();
}

CajeroWindow::~CajeroWindow()
{
    delete ui;
}

void CajeroWindow::cargarPedidosDelSistema()
{
    ui->tableColasPedidos->setRowCount(0);
    ui->tableColasPedidos->setColumnCount(6);
    QStringList headers;
    headers << "Código" << "Alumno" << "Recreo" << "Método Pago" << "Monto Total" << "Estado";
    ui->tableColasPedidos->setHorizontalHeaderLabels(headers);
    ui->tableColasPedidos->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);

    for (int i = 0; i < SistemaBuffet::pedidosCodigos.size(); ++i) {
        ui->tableColasPedidos->insertRow(i);
        ui->tableColasPedidos->setItem(i, 0, new QTableWidgetItem(SistemaBuffet::pedidosCodigos[i]));
        ui->tableColasPedidos->setItem(i, 1, new QTableWidgetItem(SistemaBuffet::pedidosAlumnos[i] + " (" + SistemaBuffet::pedidosCursos[i] + ")"));
        ui->tableColasPedidos->setItem(i, 2, new QTableWidgetItem(SistemaBuffet::pedidosRecreos[i]));
        ui->tableColasPedidos->setItem(i, 3, new QTableWidgetItem(SistemaBuffet::pedidosMetodos[i]));
        ui->tableColasPedidos->setItem(i, 4, new QTableWidgetItem("$" + QString::number(SistemaBuffet::pedidosMontos[i], 'f', 0)));

        QString estado = SistemaBuffet::pedidosEstados[i];
        QTableWidgetItem *itemEstado = new QTableWidgetItem(estado);
        if (estado == "PENDIENTE") {
            itemEstado->setForeground(QBrush(QColor(180, 100, 0)));
        } else if (estado == "ENTREGADO") {
            itemEstado->setForeground(QBrush(QColor(40, 140, 40)));
        } else if (estado == "CANCELADO") {
            itemEstado->setForeground(QBrush(QColor(180, 40, 40)));
        }
        ui->tableColasPedidos->setItem(i, 5, itemEstado);
    }
}

void CajeroWindow::on_tableColasPedidos_cellClicked(int row, int column)
{
    Q_UNUSED(column);
    if (row >= 0 && row < ui->tableColasPedidos->rowCount()) {
        QTableWidgetItem *item = ui->tableColasPedidos->item(row, 0);
        if (item) {
            ui->txtCodigoRetiro->setText(item->text());
            on_btnBuscarCodigo_clicked();
        }
    }
}

void CajeroWindow::on_btnBuscarCodigo_clicked()
{
    QString codigo = ui->txtCodigoRetiro->text().trimmed().toUpper();

    if (codigo.isEmpty()) {
        QMessageBox::warning(this, "Código Requerido", "Por favor ingresa el código de retiro.");
        return;
    }

    int idx = SistemaBuffet::pedidosCodigos.indexOf(codigo);

    if (idx == -1) {
        ui->lblStatusPedido->setText("❌ PEDIDO NO ENCONTRADO");
        ui->btnEntregarPedido->setEnabled(false);
        ui->btnCancelarPedido->setEnabled(false);
        QMessageBox::critical(this, "No Encontrado",
            QString("No se encontró ningún pedido registrado con el código '%1'.").arg(codigo));
        return;
    }

    m_codigoActual = codigo;
    QString estado = SistemaBuffet::pedidosEstados[idx];

    if (estado == "ENTREGADO") {
        ui->lblStatusPedido->setText("⚠️ ATENCIÓN: ESTE PEDIDO YA FUE ENTREGADO");
        ui->lblStatusPedido->setStyleSheet("color: #b78103; font-weight: bold;");
        ui->btnEntregarPedido->setEnabled(false);
        ui->btnCancelarPedido->setEnabled(false);
        QMessageBox::warning(this, "Pedido Entregado",
            QString("El pedido '%1' ya fue entregado y cobrado.").arg(codigo));
    } else if (estado == "CANCELADO") {
        ui->lblStatusPedido->setText("❌ ATENCIÓN: ESTE PEDIDO FUE ANULADO");
        ui->lblStatusPedido->setStyleSheet("color: #c62828; font-weight: bold;");
        ui->btnEntregarPedido->setEnabled(false);
        ui->btnCancelarPedido->setEnabled(false);
        QMessageBox::warning(this, "Pedido Cancelado",
            QString("El pedido '%1' fue cancelado y no puede ser entregado.").arg(codigo));
    } else {
        ui->lblStatusPedido->setText("✅ PEDIDO ENCONTRADO - PENDIENTE DE ENTREGA");
        ui->lblStatusPedido->setStyleSheet("color: #2e7d32; font-weight: bold;");
        ui->btnEntregarPedido->setEnabled(true);
        ui->btnCancelarPedido->setEnabled(true);
    }

    ui->lblDetalleAlumno->setText(QString("<b>Alumno:</b> %1 (DNI: %2 - %3)")
        .arg(SistemaBuffet::pedidosAlumnos[idx], SistemaBuffet::pedidosDnis[idx], SistemaBuffet::pedidosCursos[idx]));
    ui->lblDetalleRecreo->setText(QString("<b>Horario:</b> %1 | <b>Pago:</b> %2")
        .arg(SistemaBuffet::pedidosRecreos[idx], SistemaBuffet::pedidosMetodos[idx]));

    ui->tableDetalleItems->setRowCount(0);
    ui->tableDetalleItems->setColumnCount(3);
    QStringList headers;
    headers << "Detalle Producto" << "Cantidad" << "Subtotal";
    ui->tableDetalleItems->setHorizontalHeaderLabels(headers);
    ui->tableDetalleItems->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);

    QStringList lineas = SistemaBuffet::pedidosDetalles[idx].split('\n', Qt::SkipEmptyParts);
    for (int i = 0; i < lineas.size(); ++i) {
        ui->tableDetalleItems->insertRow(i);
        ui->tableDetalleItems->setItem(i, 0, new QTableWidgetItem(lineas[i].trimmed()));
        ui->tableDetalleItems->setItem(i, 1, new QTableWidgetItem("-"));
        ui->tableDetalleItems->setItem(i, 2, new QTableWidgetItem("-"));
    }

    QString textoTotal = QString("Total a Cobrar: $%1").arg(QString::number(SistemaBuffet::pedidosMontos[idx], 'f', 0));
    if (SistemaBuffet::pedidosMetodos[idx].contains("Efectivo", Qt::CaseInsensitive)) {
        textoTotal += QString(" (Abona con $%1 - Dar Vuelto: $%2)")
            .arg(QString::number(SistemaBuffet::pedidosAbonados[idx], 'f', 0))
            .arg(QString::number(SistemaBuffet::pedidosVueltos[idx], 'f', 0));
    }
    ui->lblTotalMonto->setText(textoTotal);
}

void CajeroWindow::on_btnEntregarPedido_clicked()
{
    if (m_codigoActual.isEmpty()) return;

    int idx = SistemaBuffet::pedidosCodigos.indexOf(m_codigoActual);
    if (idx != -1) {
        SistemaBuffet::pedidosEstados[idx] = "ENTREGADO";
    }

    ui->lblStatusPedido->setText("🎉 PEDIDO ENTREGADO Y COBRADO EXITOSAMENTE");
    ui->lblStatusPedido->setStyleSheet("color: #2e7d32; font-weight: bold;");
    ui->btnEntregarPedido->setEnabled(false);
    ui->btnCancelarPedido->setEnabled(false);

    cargarPedidosDelSistema();

    QMessageBox::information(this, "Entrega Confirmada",
        QString("El pedido '%1' ha sido marcado como ENTREGADO.").arg(m_codigoActual));
}

void CajeroWindow::on_btnCancelarPedido_clicked()
{
    if (m_codigoActual.isEmpty()) return;

    bool ok = false;
    QString motivo = QInputDialog::getText(this, "Cancelar Pedido",
        "Ingresa el motivo de anulación del pedido:", QLineEdit::Normal, "Cancelado a solicitud del alumno", &ok);

    if (!ok || motivo.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Motivo Requerido", "Es obligatorio ingresar un motivo para anular un pedido.");
        return;
    }

    int idx = SistemaBuffet::pedidosCodigos.indexOf(m_codigoActual);
    if (idx != -1) {
        SistemaBuffet::pedidosEstados[idx] = "CANCELADO";
    }

    ui->lblStatusPedido->setText("❌ PEDIDO CANCELADO");
    ui->lblStatusPedido->setStyleSheet("color: #c62828; font-weight: bold;");
    ui->btnEntregarPedido->setEnabled(false);
    ui->btnCancelarPedido->setEnabled(false);

    cargarPedidosDelSistema();

    QMessageBox::warning(this, "Pedido Cancelado",
        QString("El pedido '%1' ha sido anulado.").arg(m_codigoActual));
}

void CajeroWindow::on_btnLogout_clicked()
{
    LoginWindow *loginWin = new LoginWindow();
    loginWin->show();
    this->close();
}
