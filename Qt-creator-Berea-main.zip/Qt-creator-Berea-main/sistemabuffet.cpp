#include "sistemabuffet.h"

// Definición e inicialización de variables estáticas
QString SistemaBuffet::usuarioNombre = "Jorge";
QString SistemaBuffet::usuarioApellido = "Dahan";
QString SistemaBuffet::usuarioCurso = "4° Año B";
QString SistemaBuffet::usuarioDni = "44123456";
double SistemaBuffet::usuarioSaldo = 10000.0;

QList<int> SistemaBuffet::carritoIds;
QStringList SistemaBuffet::carritoNombres;
QList<double> SistemaBuffet::carritoPrecios;
QList<int> SistemaBuffet::carritoCantidades;

QStringList SistemaBuffet::pedidosCodigos;
QStringList SistemaBuffet::pedidosAlumnos;
QStringList SistemaBuffet::pedidosCursos;
QStringList SistemaBuffet::pedidosDnis;
QStringList SistemaBuffet::pedidosRecreos;
QStringList SistemaBuffet::pedidosMetodos;
QList<double> SistemaBuffet::pedidosMontos;
QList<double> SistemaBuffet::pedidosAbonados;
QList<double> SistemaBuffet::pedidosVueltos;
QStringList SistemaBuffet::pedidosEstados;
QStringList SistemaBuffet::pedidosDetalles;

void SistemaBuffet::inicializarDatos()
{
    static bool inicializado = false;
    if (inicializado) return;
    inicializado = true;

    // Pedido de ejemplo 1
    pedidosCodigos.append("3C6MB");
    pedidosAlumnos.append("Jorge Dahan");
    pedidosCursos.append("4° Año B");
    pedidosDnis.append("44123456");
    pedidosRecreos.append("1er Recreo TM (10:35 hs)");
    pedidosMetodos.append("Efectivo en Mostrador");
    pedidosMontos.append(4100.0);
    pedidosAbonados.append(5000.0);
    pedidosVueltos.append(900.0);
    pedidosEstados.append("PENDIENTE");
    pedidosDetalles.append("1x Sándwich de Milanesa ($2800)\n1x Gaseosa 500ml ($1300)");

    // Pedido de ejemplo 2
    pedidosCodigos.append("8A2KP");
    pedidosAlumnos.append("Lucía Gómez");
    pedidosCursos.append("5° Año A");
    pedidosDnis.append("45987654");
    pedidosRecreos.append("1er Recreo TM (10:35 hs)");
    pedidosMetodos.append("Saldo Cuenta Escolar");
    pedidosMontos.append(2800.0);
    pedidosAbonados.append(2800.0);
    pedidosVueltos.append(0.0);
    pedidosEstados.append("PENDIENTE");
    pedidosDetalles.append("1x Sándwich de Milanesa ($2800)");
}

void SistemaBuffet::agregarAlCarrito(int id, QString nombre, double precio, int cantidad)
{
    // Si ya existe el producto en el carrito, sumar la cantidad
    for (int i = 0; i < carritoIds.size(); ++i) {
        if (carritoIds[i] == id) {
            carritoCantidades[i] += cantidad;
            return;
        }
    }

    // Si es nuevo, añadirlo a las listas
    carritoIds.append(id);
    carritoNombres.append(nombre);
    carritoPrecios.append(precio);
    carritoCantidades.append(cantidad);
}

void SistemaBuffet::vaciarCarrito()
{
    carritoIds.clear();
    carritoNombres.clear();
    carritoPrecios.clear();
    carritoCantidades.clear();
}

double SistemaBuffet::getTotalCarrito()
{
    double total = 0.0;
    for (int i = 0; i < carritoPrecios.size(); ++i) {
        total += carritoPrecios[i] * carritoCantidades[i];
    }
    return total;
}

int SistemaBuffet::getCantidadTotalCarrito()
{
    int cant = 0;
    for (int i = 0; i < carritoCantidades.size(); ++i) {
        cant += carritoCantidades[i];
    }
    return cant;
}
