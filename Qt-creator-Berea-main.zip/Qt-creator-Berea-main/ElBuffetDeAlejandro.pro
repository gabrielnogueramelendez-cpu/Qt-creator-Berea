QT       += widgets sql

CONFIG += c++17

SOURCES += \
    main.cpp \
    sistemabuffet.cpp \
    loginwindow.cpp \
    registerdialog.cpp \
    mainwindow.cpp \
    carritodialog.cpp \
    pagodialog.cpp \
    productdetaildialog.cpp \
    comprobantedialog.cpp \
    cajerowindow.cpp \
    adminwindow.cpp \
    devwindow.cpp

HEADERS += \
    sistemabuffet.h \
    loginwindow.h \
    registerdialog.h \
    mainwindow.h \
    carritodialog.h \
    pagodialog.h \
    productdetaildialog.h \
    comprobantedialog.h \
    cajerowindow.h \
    adminwindow.h \
    devwindow.h

FORMS += \
    loginwindow.ui \
    registerdialog.ui \
    mainwindow.ui \
    carritodialog.ui \
    pagodialog.ui \
    productdetaildialog.ui \
    comprobantedialog.ui \
    cajerowindow.ui \
    adminwindow.ui \
    devwindow.ui
