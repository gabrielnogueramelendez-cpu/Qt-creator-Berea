#include "loginwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // Estilo global para los botones con cambio de color en estado hover
    a.setStyleSheet(
        "QPushButton {"
        "    background-color: #E06D53;"
        "    color: #FFFFFF;"
        "    border: 1px solid #D05D43;"
        "    border-radius: 6px;"
        "    padding: 6px 14px;"
        "    font-weight: bold;"
        "    font-size: 13px;"
        "}"
        "QPushButton:hover {"
        "    background-color: #C85A42;"
        "    border: 1px solid #B04A34;"
        "}"
        "QPushButton:pressed {"
        "    background-color: #A84530;"
        "}"
        "QPushButton:disabled {"
        "    background-color: #DDDDDD;"
        "    color: #888888;"
        "    border: 1px solid #CCCCCC;"
        "}"
    );

    LoginWindow w;
    w.show();

    return a.exec();
}
