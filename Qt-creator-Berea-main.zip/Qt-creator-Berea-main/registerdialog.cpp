#include "registerdialog.h"
#include "ui_registerdialog.h"
#include "sistemabuffet.h"
#include <QMessageBox>

RegisterDialog::RegisterDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RegisterDialog)
{
    ui->setupUi(this);
    setWindowTitle("Registro de Alumno - El Buffet de Alejandro");
    aplicarValidadores();
}

RegisterDialog::~RegisterDialog()
{
    delete ui;
}

void RegisterDialog::aplicarValidadores()
{
    // Limitar longitud máxima de campos sin bloquear la escritura
    ui->txtRegDni->setMaxLength(8);
    ui->txtRegPass->setMaxLength(12);
    ui->txtRegNombre->setMaxLength(40);
    ui->txtRegApellido->setMaxLength(40);
    ui->txtRegCurso->setMaxLength(20);
    ui->txtRegEmail->setMaxLength(50);
}

void RegisterDialog::on_btnRegisterConfirm_clicked()
{
    QString nombre = ui->txtRegNombre->text().trimmed();
    QString apellido = ui->txtRegApellido->text().trimmed();
    QString dni = ui->txtRegDni->text().trimmed();
    QString curso = ui->txtRegCurso->text().trimmed();
    QString email = ui->txtRegEmail->text().trimmed();
    QString password = ui->txtRegPass->text();

    // Validación de campos obligatorios
    if (nombre.isEmpty() || apellido.isEmpty() || dni.isEmpty() || curso.isEmpty() || email.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Campos Incompletos", "Por favor complete todos los campos obligatorios del formulario.");
        return;
    }

    // Validación de longitud de DNI
    if (dni.length() < 7 || dni.length() > 8) {
        QMessageBox::warning(this, "DNI Inválido", "El DNI debe tener entre 7 y 8 dígitos numéricos (sin puntos).");
        return;
    }

    // Validación de nombre y apellido
    if (nombre.length() < 2 || apellido.length() < 2) {
        QMessageBox::warning(this, "Nombre o Apellido Corto", "El nombre y el apellido deben tener al menos 2 caracteres.");
        return;
    }

    // Validación de correo escolar
    if (!email.contains("@")) {
        QMessageBox::warning(this, "Correo Inválido", "El correo ingresado debe contener '@' (ej: alumno@bue.edu.ar).");
        return;
    }

    // Validación de contraseña
    if (password.length() < 4) {
        QMessageBox::warning(this, "Contraseña Corta", "La contraseña debe tener al menos 4 caracteres.");
        return;
    }

    // Guardar datos del estudiante registrado
    SistemaBuffet::usuarioDni = dni;
    SistemaBuffet::usuarioNombre = nombre;
    SistemaBuffet::usuarioApellido = apellido;
    SistemaBuffet::usuarioCurso = curso;
    SistemaBuffet::usuarioSaldo = 15000.0;

    QMessageBox::information(this, "¡Registro Exitoso!",
        QString("¡Bienvenido/a %1!\nTu cuenta de estudiante ha sido registrada con DNI %2.\nYa puedes iniciar sesión en el buffet.")
            .arg(nombre, dni));
    accept();
}
